# هذا ربي — Android prototype

Initial Android WebView app pointing to https://www.itsmygod.org/.

## Build on GitHub
Upload the contents of this ZIP to the repository ROOT (not inside a nested folder), including `.github/workflows/build-apk.yml`. Then Actions > Build Android APK > Run workflow. After success, download `hatha-rabbi-debug-apk` artifact and extract `app-debug.apk`.

**Prototype limitations:** This is a WebView shell. Background voice recognition on a locked phone, native notifications, offline downloads, and playlists are NOT implemented. APK is a debug build for testing, not a signed release suitable for Play Store.
